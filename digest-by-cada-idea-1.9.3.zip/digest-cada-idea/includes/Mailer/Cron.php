<?php
namespace Boletines\Mailer;

use Boletines\Plugin;
use Boletines\Models\Campaign;
use Boletines\Models\CampaignEmail;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cron que procesa la cola por lotes respetando el límite de velocidad.
 * Usa un lock transitorio para evitar que dos ejecuciones se pisen
 * (estilo Newsletter de Lissa).
 */
class Cron {

	const LOCK_KEY     = 'boletines_send_lock';
	const COUNTER_KEY  = 'boletines_sent_window';

	public function register(): void {
		add_action( 'boletines_cron_send', array( $this, 'tick' ) );
		// Permite forzar el envío vía URL desde el admin (?action=boletines_run_now).
		add_action( 'admin_post_boletines_run_now', array( $this, 'manual_run' ) );

		// Activar campañas programadas cuya hora ya llegó.
		add_action( 'boletines_cron_send', array( $this, 'activate_scheduled' ), 5 );
	}

	public function manual_run(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'boletines' ) );
		}
		check_admin_referer( 'boletines_run_now' );
		$this->tick();
		wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=boletines' ) );
		exit;
	}

	/** Pasa campañas 'scheduled' a 'sending' cuando llega su hora. */
	public function activate_scheduled(): void {
		global $wpdb;
		$tbl = Plugin::table( 'campaigns' );
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$tbl} SET status = %s, updated_at = %s
				 WHERE status = %s AND scheduled_at IS NOT NULL AND scheduled_at <= %s",
				Campaign::STATUS_SENDING,
				current_time( 'mysql' ),
				Campaign::STATUS_SCHEDULED,
				current_time( 'mysql' )
			)
		);

		// Construir cola para las que acaban de pasar a 'sending' y aún no la tienen.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT id FROM {$tbl} WHERE status = %s AND total_recipients = 0", Campaign::STATUS_SENDING ),
			ARRAY_A
		);
		foreach ( $rows as $r ) {
			Campaign::build_queue( (int) $r['id'] );
		}
	}

	public function tick(): void {
		// Lock para que dos ejecuciones no envíen los mismos correos.
		if ( get_transient( self::LOCK_KEY ) ) {
			return;
		}
		set_transient( self::LOCK_KEY, time(), 5 * MINUTE_IN_SECONDS );

		try {
			$speed_per_hour = max( 1, (int) Plugin::get_setting( 'speed_per_hour', 240 ) );
			$batch_size     = max( 1, (int) Plugin::get_setting( 'batch_size', 20 ) );

			// Cuántos hemos mandado en la última hora?
			$sent_in_window = $this->sent_in_last_hour();
			$remaining      = max( 0, $speed_per_hour - $sent_in_window );

			if ( 0 === $remaining ) {
				return;
			}

			$to_send = min( $batch_size, $remaining );
			$rows    = CampaignEmail::claim_batch( $to_send, getmypid() ?: 1 );
			if ( empty( $rows ) ) {
				return;
			}

			$mailer = new Mailer();

			foreach ( $rows as $row ) {
				$result = $mailer->send_queued( $row );

				if ( true === $result ) {
					CampaignEmail::mark_sent( (int) $row['id'] );
					CampaignEmail::increment_campaign_sent( (int) $row['campaign_id'] );
					$this->bump_counter();
				} else {
					CampaignEmail::mark_failed( (int) $row['id'], (string) $result );
				}
			}

			// Cerrar campañas que ya terminaron.
			$campaign_ids = array_unique( array_map( 'intval', wp_list_pluck( $rows, 'campaign_id' ) ) );
			foreach ( $campaign_ids as $cid ) {
				CampaignEmail::maybe_finalize_campaign( $cid );
			}
		} finally {
			delete_transient( self::LOCK_KEY );
		}
	}

	/**
	 * Cuenta cuántos correos se enviaron en la última hora consultando timestamps.
	 * Usamos un contador en memoria (transient) para velocidad y la BD como respaldo.
	 */
	private function sent_in_last_hour(): int {
		global $wpdb;
		$tbl = Plugin::table( 'campaign_emails' );
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$tbl} WHERE status = %s AND sent_at >= %s",
				CampaignEmail::STATUS_SENT,
				gmdate( 'Y-m-d H:i:s', time() - HOUR_IN_SECONDS )
			)
		);
	}

	private function bump_counter(): void {
		// Reservado para una optimización futura con transients.
	}
}
