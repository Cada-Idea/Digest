<?php
namespace Boletines\Mailer;

use Boletines\Plugin;
use Boletines\Models\CampaignEmail;
use Boletines\Models\Subscriber;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Núcleo de envío. Usa wp_mail() para que sea compatible con cualquier
 * plugin SMTP (FluentSMTP, WP Mail SMTP, Post SMTP, etc.).
 */
class Mailer {

	/**
	 * Envía un único correo de la cola.
	 *
	 * @param array $row Fila de campaign_emails con datos JOIN del suscriptor y campaña.
	 * @return true|string TRUE si OK, string con mensaje de error si falla.
	 */
	public function send_queued( array $row ) {
		$subscriber = array(
			'id'         => (int) $row['subscriber_id'],
			'email'      => $row['email'],
			'first_name' => $row['first_name'] ?? '',
			'last_name'  => $row['last_name'] ?? '',
			'token'      => $row['subscriber_token'] ?? '',
		);

		// 1) Procesar shortcodes embebidos (posts, productos, populares...).
		$body = do_shortcode( $row['body_html'] );
		// 2) Personalizar variables {first_name}, {site_name}, etc.
		$body = $this->personalize( $body, $subscriber );
		// 3) Envolver con branding (header logo + footer redes + texto custom + preferencias/baja).
		$body = Branding::wrap( $body, array(
			'preheader'  => $row['preheader'] ?? '',
			'subscriber' => $subscriber, // <-- Branding genera legal_footer automáticamente
		) );
		// 4) Inyectar tracking (pixel + click rewrite).
		$body = $this->inject_tracking( $body, $row['tracking_token'] );

		// 5) Personalizar variables {email}, {first_name}, etc. tanto en body como en subject.
		// Se hace DESPUÉS del tracking para que las URLs no se vean afectadas y ANTES del envío.
		$body    = \Boletines\Mailer\Branding::personalize_text( $body, $subscriber );
		$subject = $this->personalize( $row['subject'], $subscriber );

		$from_name  = $row['from_name'] ?: Plugin::get_setting( 'from_name', get_bloginfo( 'name' ) );
		$from_email = $row['from_email'] ?: Plugin::get_setting( 'from_email', get_option( 'admin_email' ) );
		$reply_to   = $row['reply_to'] ?: $from_email;

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $this->encode_header( $from_name ) . ' <' . $from_email . '>',
			'Reply-To: ' . $reply_to,
			// One-Click Unsubscribe (RFC 8058) - obligatorio para Gmail/Yahoo desde 2024.
			'List-Unsubscribe: <' . esc_url_raw( $this->unsubscribe_url( $subscriber ) ) . '>',
			'List-Unsubscribe-Post: List-Unsubscribe=One-Click',
			'X-Boletines-Token: ' . $row['tracking_token'],
		);

		// Capturar errores de wp_mail.
		$error_msg = '';
		$catch     = function ( $e ) use ( &$error_msg ) {
			$error_msg = is_object( $e ) && method_exists( $e, 'get_error_message' )
				? $e->get_error_message()
				: 'wp_mail falló sin mensaje';
		};
		add_action( 'wp_mail_failed', $catch );

		$ok = wp_mail( $subscriber['email'], $subject, $body, $headers );

		remove_action( 'wp_mail_failed', $catch );

		if ( $ok ) {
			return true;
		}
		return $error_msg ?: 'wp_mail devolvió FALSE';
	}

	/**
	 * Envía un correo "sencillo" (no de campaña): doble opt-in, bienvenida, etc.
	 */
	public function send_simple( string $to, string $subject, string $body_html, array $headers_extra = array(), ?array $subscriber = null ): bool {
		$from_name  = Plugin::get_setting( 'from_name', get_bloginfo( 'name' ) );
		$from_email = Plugin::get_setting( 'from_email', get_option( 'admin_email' ) );
		$reply_to   = Plugin::get_setting( 'reply_to', $from_email );

		$headers = array_merge(
			array(
				'Content-Type: text/html; charset=UTF-8',
				'From: ' . $this->encode_header( $from_name ) . ' <' . $from_email . '>',
				'Reply-To: ' . $reply_to,
			),
			$headers_extra
		);

		$body = Branding::wrap( wpautop( $body_html ), array(
			'preheader'  => '',
			'subscriber' => $subscriber, // si es null, Branding mostrará footer mínimo sin links de preferencias
		) );

		return (bool) wp_mail( $to, $subject, $body, $headers );
	}

	// ------------------------------------------------------------------
	// Helpers
	// ------------------------------------------------------------------

	private function personalize( string $text, array $subscriber ): string {
		// Delegamos a Branding::personalize_text (única fuente de verdad para las
		// variables permitidas: {first_name}, {last_name}, {full_name}, {email},
		// {site_name}, {site_url}, {current_year}. Acepta también doble llave).
		return \Boletines\Mailer\Branding::personalize_text( $text, $subscriber );
	}

	/**
	 * Reemplaza enlaces por la URL de tracking + añade pixel 1x1.
	 */
	private function inject_tracking( string $html, string $token ): string {
		$track_base = home_url( '/?boletines_track=click&t=' . rawurlencode( $token ) . '&u=' );

		// Reemplazar href="..." en enlaces (no en mailto: ni anclas internas ni tracking ya hecho).
		$html = preg_replace_callback(
			'#<a\s+([^>]*?)href\s*=\s*"([^"]+)"([^>]*)>#i',
			function ( $m ) use ( $track_base ) {
				$url = $m[2];
				if ( strpos( $url, 'mailto:' ) === 0 || strpos( $url, '#' ) === 0 || strpos( $url, '{' ) === 0 ) {
					return $m[0];
				}
				if ( strpos( $url, 'boletines_track=' ) !== false ) {
					return $m[0];
				}
				$tracked = $track_base . rawurlencode( $url );
				return '<a ' . $m[1] . 'href="' . $tracked . '"' . $m[3] . '>';
			},
			$html
		);

		// Pixel de apertura.
		$pixel_url = home_url( '/?boletines_track=open&t=' . rawurlencode( $token ) );
		$pixel     = '<img src="' . esc_url( $pixel_url ) . '" width="1" height="1" alt="" style="display:block;border:0;width:1px;height:1px;" />';

		// Insertar antes de </body> si existe; si no, al final.
		if ( stripos( $html, '</body>' ) !== false ) {
			$html = str_ireplace( '</body>', $pixel . '</body>', $html );
		} else {
			$html .= $pixel;
		}

		return $html;
	}

	/**
	 * Devuelve el HTML del bloque legal con unsubscribe + preferencias.
	 * @deprecated v1.7 — la lógica vive en Branding\Branding::build_legal_footer().
	 * Mantenido por compatibilidad si lo llama código externo.
	 */
	private function legal_footer_html( array $subscriber ): string {
		return Branding::build_legal_footer( $subscriber );
	}

	private function preferences_url( array $subscriber ): string {
		return Branding::preferences_url( $subscriber );
	}

	private function unsubscribe_url( array $subscriber ): string {
		return add_query_arg(
			array(
				'boletines_action' => 'unsubscribe',
				'sid'              => $subscriber['id'],
				'token'            => $subscriber['token'],
			),
			home_url( '/' )
		);
	}

	private function encode_header( string $value ): string {
		// Si el nombre tiene caracteres no-ASCII, codificar como MIME.
		if ( preg_match( '/[\x80-\xff]/', $value ) ) {
			return '=?UTF-8?B?' . base64_encode( $value ) . '?=';
		}
		return '"' . str_replace( '"', '', $value ) . '"';
	}
}
